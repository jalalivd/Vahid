

test('renders learn react link', () => {
  console.log("Test");
});
