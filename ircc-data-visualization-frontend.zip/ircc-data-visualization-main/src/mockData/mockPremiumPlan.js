let premiumPlan = [
    {
        "id": "1",
        "description": "97335477-be20-4fdd-bf11-f9f9f05c30a1",
        "plan_name": "free",
        "plan_price": "0",
        "image": "/user-icons/elon-musk.png"
    },
    {
        "id": "2",
        "description": "ca7febdb-c14d-4f8d-92ca-0ec2d81505ba",
        "plan_name": "monthly",
        "plan_price": "200",
        "image": "/user-icons/elon-musk.png"
    },
    {
        "id": "3",
        "description": "ca7febdb-c14d-4f8d-92ca-0ec2d81505ba",
        "plan_name": "monthly",
        "plan_price": "200",
        "image": "/user-icons/elon-musk.png"
    },
]

export default premiumPlan;
