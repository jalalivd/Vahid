let premiumPlan = [
    {
        "id": "1",
        "description": "97335477-be20-4fdd-bf11-f9f9f05c30a1",
        "plan_name": "1 Month",
        "plan_price": "$30",
        "month": 1,
        "image": "/user-icons/elon-musk.png"
    },
    {
        "id": "2",
        "description": "ca7febdb-c14d-4f8d-92ca-0ec2d81505ba",
        "plan_name": "6 Months",
        "plan_price": "$120",
        "month": 6,
        "image": "/user-icons/elon-musk.png"
    },
    {
        "id": "3",
        "description": "ca7febdb-c14d-4f8d-92ca-0ec2d81505ba",
        "plan_name": "1 Year",
        "plan_price": "$180",
        "month": 12,
        "image": "/user-icons/elon-musk.png"
    },
]

export default premiumPlan;
